package com.varxyz.banking.domain;

public class InsuffientBalanceException extends RuntimeException{
	public InsuffientBalanceException(String msg) {
		super(msg);
	}
}
